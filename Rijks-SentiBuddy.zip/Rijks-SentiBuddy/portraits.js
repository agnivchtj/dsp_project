let products = {
  data: [
    {
      productName: "Portrait of an Old Man",
      category: "Sad",
      image: "sad1.jpg",
    },
    {
      productName: "Portrait of Eduard Wallis",
      category: "Sad",
      image: "sad2.jpg",
    },
    {
      productName: "Portrait of a man",
      category: "Sad",
      image: "sad3.jpg",
    },
    {
      productName: "Self-portrait, Rembrandt van Rijn",
      category: "Sad",
      image: "sad4.jpg",
    },
    {
      productName: "Dirck Volkertsz Coornhert",
      category: "Sad",
      image: "sad5.jpg",
    },
    {
      productName: "Rembrandt's Son Titus in a Monk's Habit",
      category: "Sad",
      image: "sad6.jpg",
    },      {
      productName: "A Young Woman Warming her Hands over a Brazier: Allegory of Winter",
      category: "Sad",
      image: "sad7.jpg",
    },
    {
      productName: "The Prayer without End",
      category: "Sad",
      image: "sad8.jpg",
    },
    {
      productName: "Prophetess Anna",
      category: "Sad",
      image: "sad9.jpg",
    },
    {
      productName: "Portrait of Ephraim Bueno",
      category: "Sad",
      image: "sad10.jpg",
    },
    {
      productName: "Jeremiah Lamenting the Destruction of Jerusalem",
      category: "Sad",
      image: "sad11.jpg",
    },
    {
      productName: "Portrait of a Haarlem Citizen",
      category: "Sad",
      image: "sad12.jpg",
    },
    {
      productName: "Wilhelmina Margaretha van den Bosch",
      category: "Sad",
      image: "sad13.jpg",
    },
    {
      productName: "Old Woman Reading",
      category: "Sad",
      image: "sad14.jpg",
    },
    {
      productName: "Portrait of a Wounded KNIL Soldier",
      category: "Sad",
      image: "sad15.jpg",
    },
    {
      productName: "Portrait of a young woman",
      category: "Angry",
      image: "angry1.jpg",
    },
    {
      productName: "Self-portrait, Jan Havicksz. Steen",
      category: "Angry",
      image: "angry2.jpg",
    },
    {
      productName: "Portrait of a woman",
      category: "Angry",
      image: "angry3.jpg",
    },
    {
      productName: "Self-Portrait, Adriaen Hanneman",
      category: "Angry",
      image: "angry4.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Angry",
      image: "angry5.jpg",
    },
    {
      productName: "Portrait of Johannes Lutma",
      category: "Angry",
      image: "angry6.jpg",
    },
    {
      productName: "Filips de Schone",
      category: "Angry",
      image: "angry7.jpg",
    },
    {
      productName: "Portrait of a Woman, Giovanni Bellini",
      category: "Angry",
      image: "angry8.jpg",
    },
    {
      productName: "Portrait of an Old Man, probably Vercellino Olivazzi, Senator from Bergamo",
      category: "Angry",
      image: "angry9.jpg",
    },
    {
      productName: "Portrait of an officer of the Leiden civic guard in front of the gate of the headquarters of the St. George guards",
      category: "Angry",
      image: "angry10.jpg",
    },
    {
      productName: "Portrait of a Painter",
      category: "Angry",
      image: "angry11.jpg",
    },
    {
      productName: "Pieter Harme Witkamp",
      category: "Angry",
      image: "angry12.jpg",
    },
    {
      productName: "Portrait of Anthony de Wale",
      category: "Angry",
      image: "angry13.jpg",
    },
    {
      productName: "Portrait of Maurice, Prince of Orange",
      category: "Angry",
      image: "angry14.jpg",
    },
    {
      productName: "Portrait of Gerard Reynst, Governor-General of the Dutch East Indies",
      category: "Angry",
      image: "angry15.jpg",
    },
    {
      productName: "Portrait of a painter, presumably a self-portrait",
      category: "Happy",
      image: "happy1.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Happy",
      image: "happy2.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Happy",
      image: "happy3.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Happy",
      image: "happy4.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Happy",
      image: "happy5.jpg",
    },
    {
      productName: "Portrait of a little boy",
      category: "Happy",
      image: "happy6.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Happy",
      image: "happy7.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Happy",
      image: "happy8.jpg",
    },
    {
      productName: "Portrait of a historian",
      category: "Happy",
      image: "happy9.jpg",
    },
    {
      productName: "Portrait of Queen Elizabeth I",
      category: "Happy",
      image: "happy10.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Happy",
      image: "happy11.jpg",
    },
    {
      productName: "Self-Portrait of Hendrik van Limborch",
      category: "Happy",
      image: "happy12.jpg",
    },
    {
      productName: "Portrait of Maria Trip",
      category: "Happy",
      image: "happy13.jpg",
    },
    {
      productName: "Portrait of a Girl Dressed in Blue",
      category: "Happy",
      image: "happy14.jpg",
    },
    {
      productName: "Portrait of Jacob Cats ",
      category: "Neutral",
      image: "neutral1.jpg",
    },
    {
      productName: "Portrait of Adriana Croes",
      category: "Neutral",
      image: "neutral2.jpg",
    },
    {
      productName: "Portrait of Amalia van Solms",
      category: "Neutral",
      image: "neutral3.jpg",
    },
    {
      productName: "Portrait of Ambrogio Spinola",
      category: "Neutral",
      image: "neutral4.jpg",
    },
    {
      productName: "Portrait of Pieter van Son ",
      category: "Neutral",
      image: "neutral 5.jpg",
    },
    {
      productName: "Portrait of Henrick Hooft",
      category: "Neutral",
      image: "neutral6.jpg",
    },
    {
      productName: "Portrait of Maria Petitpas",
      category: "Neutral",
      image: "neutral 7.jpg",
    },
    {
      productName: "Portrait of a Nobleman in Armor ",
      category: "Neutral",
      image: "neutral7.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral8.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral9.jpg",
    },
    {
      productName: "Portrait of a Man, Cornelis Troost",
      category: "Neutral",
      image: "neutral10.jpg",
    },
    {
      productName: "Portrait of a Woman Painting",
      category: "Neutral",
      image: "neutral11.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral12.jpg", 
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral13.jpg",
    },
    {
      productName: "Portrait of a Painter",
      category: "Neutral",
      image: "neutral14.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral15.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral16.jpg",
    },
    {
      productName: "Portrait of a Painter",
      category: "Neutral",
      image: "neutral17.jpg",
    },
    {
      productName: "Portrait of an Artist",
      category: "Neutral",
      image: "neutral18.jpg",
    },
    {
      productName: "Portrait of Nicolaes Hasselaer",
      category: "Neutral",
      image: "neutral19.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral20.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral21.jpg",
    },
    {
      productName: "Portrait of Nicolaes Hasselaer",
      category: "Neutral",
      image: "neutral19.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral20.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral21.jpg",
    },
    {
      productName: "Portrait of a Woman, Jan van Haensbergen",
      category: "Neutral",
      image: "neutral22.jpg",
    },
    {
      productName: "Portrait of Helena le Maire",
      category: "Neutral",
      image: "neutral23.jpg",
    },
    {
      productName: "Portrait of a Woman",
      category: "Neutral",
      image: "neutral24.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Neutral",
      image: "neutral25.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Fear",
      image: "fear1.jpg",
    },
    {
      productName: "Rembrandt as a Shepherd with a Staff and Flute",
      category: "Fear",
      image: "fear2.jpg",
    },
    {
      productName: "THOMAS FRYE :A self-portrait",
      category: "Fear",
      image: "fear3.jpg",
    },
    {
      productName: "Self portrait of the painter Jan Toorop",
      category: "Fear",
      image: "fear4.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Fear",
      image: "fear5.jpg",
    },
    {
      productName: "Girl in a White Kimono",
      category: "Fear",
      image: "fear6.jpg",
    },
    {
      productName: "David Garrick as Richard III",
      category: "Fear",
      image: "fear7.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Surprise",
      image: "surprise1.jpg",
    },
    {
      productName: "Portrait of a Man",
      category: "Surprise",
      image: "surprise2.jpg",
    },
    {
      productName: "Self-Portrait as the Apostle Paul",
      category: "Surprise",
      image: "surprise3.jpg",
    },
    {
      productName: "Ludolf Bakhuizen",
      category: "Surprise",
      image: "surprise4.jpg",
    },
    {
      productName: "Portrait of Constantijn Huygens ",
      category: "Surprise",
      image: "surprise5.jpg",
    },
    {
      productName: "Salomon Rendorp (1767-1824). Brouwer te Amsterdam",
      category: "Surprise",
      image: "surprise6.jpg",
    },
    {
      productName: "Portrait of Jacob Maris",
      category: "Surprise",
      image: "surprise7.jpg",
    },
    {
      productName: "Childhood portrait of Joseph Luns",
      category: "Surprise",
      image: "surprise8.jpg",
    },
    {
      productName: "Jongenskop",
      category: "Surprise",
      image: "surprise9.jpg",
    },
    {
      productName: "Portrait of Emerantia van Citters",
      category: "Surprise",
      image: "surprise10.jpg",
    },
    {
      productName: "Portrait of a Woman, Catharina van Hemessen",
      category: "Disgust",
      image: "disgust1.jpg",
    },
    {
      productName: "Self-portrait, Jan Havicksz. Steen",
      category: "Disgust",
      image: "disgust2.jpg",
    },
    {
      productName: "Self-portrait",
      category: "Disgust",
      image: "disgust3.jpg",
    },
    {
      productName: "Portrait of Gerard Andriesz Bicker",
      category: "Disgust",
      image: "disgust4.jpg",
    },
    {
      productName: "Portrait of Jacob Cornelisz van Oostsanen",
      category: "Disgust",
      image: "disgust5.jpg",
    },
    {
      productName: "The painter's fourth wife",
      category: "Disgust",
      image: "disgust6.jpg",
    },
    {
      productName: "Portrait of Roelof Meulenaer",
      category: "Disgust",
      image: "disgust7.jpg",
    },
    {
      productName: "Portrait of Lysbeth van Duvenvoorde",
      category: "Disgust",
      image: "disgust8.jpg",
    },
    {
      productName: "Portrait of Alida Gerbade",
      category: "Disgust",
      image: "disgust9.jpg",
    },
    {
      productName: "Portrait of William I. Prince of Orange, called William the Silent",
      category: "Disgust",
      image: "disgust10.jpg",
    },
  ],
};
